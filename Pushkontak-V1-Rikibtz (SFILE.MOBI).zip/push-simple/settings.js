const fs = require('fs');
const chalk = require('chalk');

/*
 
 
 
 # Script Ini Tidak Dibagikan Secarq Gratis!! No Enc ? Beli Di Developernya :)
 
 
 # Contact Developer
  * WhatsApp : 6285775414552
  * Telegram : t.me/Rikishop_x_hosting

  
 # Thanks To My Support
  * All Creator Bot WhatsApp
  * AI GPT Chat
  * 𝐑𝐈𝐊𝐈 𝐒𝐇𝐎𝐏



*/

//~~~~~~~~~< GLOBAL SETTINGS >~~~~~~~~~\\

global.owner = ['6285775414552', '6285891142486']
global.ownerUtama = "6285775414552"
global.namaOwner = "RIKI SHOP."
global.packname = 'Bot WhatsApp'
global.botname = 'Pushkontak V1.'
global.botname2 = 'Pushkontak V1'
global.tempatDB = 'database.json'
global.pairing_code = true

global.linkOwner = "https://wa.me/6285775414552"
global.linkGrup = "https://linktr.ee/rikishopreal"
global.linkGrup2 = "https://chat.whatsapp.com/I3sLdgrwUqOLGU0DWWr52s"
global.linkSaluran = "https://whatsapp.com/channel/0029VadvvgF6rsQljgBc7D1t"
global.idChannel = "120363315322575871@newsletter"
global.nameChannel = "TESTIMONI YT : RIKI SHOP [ Testimoni ]"

global.delayJpm = 4000
global.delayPushkontak = 5000
// 1000 = 1 detik


global.imageSlide = "https://telegra.ph/file/9f536e5912934d2e2de83.jpg"
global.imageMenu = "https://telegra.ph/file/9f536e5912934d2e2de83.jpg"

global.dana = "085819066475"
global.ovo = "085775414552"
global.gopay = "081400337353"
global.qris = "https://telegra.ph/file/04424a604335ab88e5707.jpg"


global.mess = {
	owner: "  \`</> [ Owner Only! ]\`\n- Fitur Ini Hanya Untuk Ownerbot!",
	admin: "  \`</> [ Admin Only! ]\`\n- Fitur Ini Hanya Untuk Admin!",
	botAdmin: "  \`</> [ Bot Admin! ]\`\n- Bot Bukan Admin!",
	group: "  \`</> [ Group Only! ]\`\n- Fitur Ini Hanya Untuk Dalam Grup!",
	private: "  \`</> [ Private Only! ]\`\n- Fitur Ini Hanya Untuk Private Chat!",
	prem: "  \`</> [ Premium Only! ]\`\n- Fitur Ini Hanya Untuk Pengguna Premium!",
	wait: 'Loading...',
	error: 'Error!',
	done: 'Done'
}
//~~~~~~~~~~~~~~~< PROCESS >~~~~~~~~~~~~~~~\\

let file = require.resolve(__filename)
fs.watchFile(file, () => {
	fs.unwatchFile(file)
	console.log(chalk.redBright(`Update ${__filename}`))
	delete require.cache[file]
	require(file)
});